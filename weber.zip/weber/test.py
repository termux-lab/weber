import requests, colorama, json
url = input("[url]: ")
ufd = url.replace("https://", "").replace("http://", "")
pars_dom = requests.post("https://www.nic.ru/app/v1/get/whois", params={"searchWord":ufd, "lang":"ru"}).text
dom_info = json.loads(pars_dom)
print(dom_info["body"]['list'][0]["formatted"])
